from Tkinter import *

def main():
	root = Tk()
	w = Label(root, text='Python is working!')
	w.pack()
	root.mainloop()