# Imports for GUI and basic functionality
from Tkinter import Frame
import Tkinter as tk
import ttk
import tkFileDialog as tkF
import math as mt
import numpy as np
import os
import nucleus_unstructured as nu # nucleus of strain - Kees
import trimesh as trim # trimesh functions of Kees
import cgschemes as cg # conjugate gradient scheme of Kees

# Imports for plotting:
import matplotlib
from matplotlib.patches import Polygon
from matplotlib.collections import PatchCollection
from matplotlib import rcParams
from matplotlib.figure import Figure
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg #, NavigationToolbar2TkAgg

# Imports for the Geomec interface
import logging
import helper
from interface import Interface
from geomec_interface import GeomecInterface

#LOG_FILE="c:\Temp\IT_py.log"
LOG_FILE="E:\IT_py.log"
#---------------------------------------------

'''
This module contains a GUI for subsidence inversion

Kees Hindriks,  v1 2015
				v2 2016
            TO DO:
                - remove the checkboxes from the GUI
                - ensure that all changes from Manel are OK (especially depletion)
'''

def notdone():
	pass

def masked(x,mask):
	'''
	function to compute mean and standard deviation from a masked vector
	'''
	mean=sum(x*mask)/sum(mask)
	stdv=mt.sqrt(sum(np.power(mask*(x-mean),2)/sum(mask)))

	return mean,stdv

def outlierdetect(recon,orig,frac):
	'''
	function for outlier detection
	input
		recon reconstructed/forward modeled observations
		orig  actual/real observations
		frac  percentage of expected outliers

	Some room for improvement is possible (i.e. use standard deviation information
	to define number of outliers, based on a confidence interval)
	'''
	try:
		#compute error
		err=orig-recon
		# define number of outliers
		nn=int(frac*float(len(err)))

		# initiate sample mask and value vector
		masker=np.ones((len(err),))
		vals=np.zeros((len(err),))

		#iterate over the number of desired outliers
		for m in range(nn):
			# compute mean and standard deviation of the error at current non-outlier locations
			mean,stdv=masked(err,masker)
			# make list of relative errors, in comparison to mean error, using the current non-outliers
			test=abs(err-mean)*masker/stdv
			# select the sample with the highest relative error
			outl=np.argmax(test)
			# set the mask for this sample to zero such that it will be excluded in the next iteration
			masker[outl]=0.
			# and make a complimentay mask
			vals[outl]=test[outl]
			vals[outl]=1.
		masker=1.-vals/max(vals)
		return masker
	except:
		helper.handle_exception()

wit="#%02x%02x%02x" % (255, 255, 255)
grijs="#%02x%02x%02x" % (190, 190, 190)
MissingValue=['-9999','-999.25','-1e+30','-999']
pi=mt.acos(0.)*2.
rcParams['font.size']=6

# set-up a list of parameters needed by the tool
parkeys=['internal iterations','external iterations','reweight iterations\noutlier detection',
		 'reduction factor','Subsidence sign']
pardef=['5','1','5','10','+']
parunits=['#','#','#','%','+ or -']
pi=mt.acos(0.)*2.

class subsinversion(Frame):
	'''
	class for handling and displaying subsidence inversion through a GUI
	'''
	def __init__(self,parent=None):

		try:
			Frame.__init__(self,parent) # FIXME: don't do the work when app is launched sevreral times; tkk app needs to be closed properly
			self.pack(expand=tk.YES,fill=tk.BOTH)

			self.master.title("Unstructured inversion")
			self.directory='.'
		
			self.makemenu(self.master)

			# make the parameter input table
			# and an execution button calling the calculation method, called doit
			rij=self.make_input()
			rij += 1

			self.make_combo(rij, "Invert for:", ['Strain','Compaction'] )
			rij += 1

			self.iface = Interface( self )

			self.b_construct=tk.Button(self,text='CONSTRUCT',command=self.construct,width=12,height=1)
			self.b_construct.grid(column=4,columnspan=1,row=rij)
			self.b_construct['state'] = 'disabled'

			self.b_execute=tk.Button(self,text='INVERT',command=self.doit,width=10,height=1)
			self.b_execute.grid(column=5,columnspan=1,row=rij)
			self.b_execute['state'] = 'disabled'

			self.b_setdep=tk.Button(self,text='SET DEPL.',command= lambda: self.iface.Pre_Cmd_Set_Depletion(GeomecInterface.Request_Id.Cmd_Set_Depletion),width=10,height=1)
			self.b_setdep.grid(column=6,columnspan=1,row=rij)
			self.b_setdep['state'] = 'disabled'

			self.btn_txt = tk.StringVar()
			self.b_rungm=tk.Button(self,textvariable=self.btn_txt,command= lambda: self.iface.Pre_Cmd_Run_Geomec( GeomecInterface.Request_Id.Cmd_Run_Geomec ),width=12,height=1)
			self.btn_txt.set("RUN GEOMEC")
			self.b_rungm.grid(column=7,columnspan=2,row=rij)
			self.b_rungm['state'] = 'disabled'

			rij += 1

			rij = self.iface.gm_init(rij)

			rij += 1

			self.subsgrid=False
			self.resgrid=False
			self.enable=False
			self.cultural=False
			self.inverted=False
			self.setrec_parlimits = False # flag to help fix color limits through iterations 

			self.nit=3
			self.nrw=5
			self.mc=1
			self.cult=[]
			self.culttype=[]

			# set-up a canvas
			self.fig=Figure(figsize=(12.5,8),dpi=100,frameon=True)
			self.display=FigureCanvasTkAgg(self.fig,master=self )
			self.display.get_tk_widget().grid( sticky=tk.W+tk.N+tk.E,row=0,rowspan=rij+1,column=11,columnspan=10)

			self.minx=-1.
			self.miny=-1.
			self.scale=2.
			self.rec_subs=np.array([-1.,1.])
		

			self.sub1=self.fig.add_subplot(334)
			self.sub2=self.fig.add_subplot(333)
			self.sub3=self.fig.add_subplot(332)
			self.sub4=self.fig.add_subplot(335)
			self.sub5=self.fig.add_subplot(331)
			self.sub7=self.fig.add_subplot(336)
			self.sub8=self.fig.add_subplot(337)
			self.sub9=self.fig.add_subplot(338)
			self.ax1=[.295,.055,.01,.4]
			self.ax2=[.64,.055,.01,.4]
			self.ax3=[.83,.78,.01,.173]
			self.ax4=[.295,.55,.01,.4]
			self.ax5=[.64,.55,.01,.4]
			ax1=self.fig.add_axes(self.ax1)
			ax2=self.fig.add_axes(self.ax2)
			ax3=self.fig.add_axes(self.ax3)
			ax4=self.fig.add_axes(self.ax4)
			ax5=self.fig.add_axes(self.ax5)
			scat=self.sub4.scatter([0.,],[0.,],s=1.,c=0.)
			self.cbar1=self.fig.colorbar(scat, cax=ax1)
			self.cbar2=self.fig.colorbar(scat, cax=ax2)
			self.cbar3=self.fig.colorbar(scat, cax=ax3)
			self.cbar4=self.fig.colorbar(scat, cax=ax4)
			self.cbar5=self.fig.colorbar(scat, cax=ax5)
			self.setplotpars()


			self.textU=tk.Text(self,relief=tk.SUNKEN,height=15,width=15,font=("Helvetica", 6))
			self.textU.grid(sticky=tk.W+tk.N+tk.E,row=rij,column=4,columnspan=5)
			self.textU.insert(1.0,'Step 1: Load and select reservoir ("Fill")\n','INFO')
			self.textU.tag_configure('INFO', font='helvetica 6 bold', relief='raised')
			self.textU.tag_configure('OK', background='green', font='helvetica 6 bold', relief='raised')
			self.textU.tag_configure('WARN', background='yellow', font='helvetica 6 bold', relief='raised')
			self.textU.tag_configure('ERROR', background='red', font='helvetica 6 bold', relief='raised')
		except:
			helper.handle_exception()
	
	def make_combo(self, rij, _label, _options):
			l=tk.Label(self,text=_label,width=10,anchor=tk.W,justify=tk.LEFT)
			l.grid(row=rij,column=4)
			self.val = tk.StringVar()
			self.invert_for = ttk.Combobox( self, textvariable=self.val )
			self.invert_for['values'] = _options
			self.invert_for.current(0)
			self.invert_for.grid(column=5,columnspan=2,row=rij,sticky=tk.W)
	
	def make_input(self):
		'''
		Generate input fields in the GUI for the settings for the inversion
		here we make a parameter input dialogue	by reading the list of parameter
		keywords	and adding input entries to it
		'''
		try:
			n=0
			n2=0
			self.pars=[]
			self.keys=[]
			self.checks=[]
			for m in parkeys:
				l=tk.Label(self,text=m,width=15,anchor=tk.W,justify=tk.LEFT)
				l.grid(row=n,column=4,columnspan=2)
				e=tk.Entry(self,width=10)
				e.insert(0,pardef[n])
				e.grid(row=n,column=6)
				self.pars.append(e)
				self.keys.append(m)
				self.checks.append(l)
				n=n+1		
			
			for m in parunits:

				l=tk.Label(self,text=m,width=5,anchor=tk.W,justify=tk.LEFT)
				l.grid(row=n2,column=7)
				n2=n2+1
			return n
		except:
			helper.handle_exception()
	
	def getinput(self):
		'''
		Obtain the inversion setting values from the input fields.
		'''
		try:
			self.inputs={}

			# get the input parameters
			for m in range(len(self.pars)):
				val=self.pars[m].get()
				key=self.keys[m]
				self.inputs[key]=val
		except:
			helper.handle_exception()

	def makemenu(self,win):
		'''
		Make a menu option for loading cultural data from an external file.
		'''
		try:
			tt=tk.Menu(win)
			win.config(menu=tt)
			filef=tk.Menu(tt)
			filef.add_command(label='Import cultural data',command=self.readcultural,underline=1)
			tt.add_cascade(label='File',menu=filef, underline=0)
		except:
			helper.handle_exception()


	def calc_triprop(self, prop, p):
		'''
		For each triangle in the surface mesh trim.trimesh, calculate its given
		property from the node values of the triangle.
		'''
		p1 = p[0]
		p2 = p[1]
		p3 = p[2]
		dum=0.
		n=0
		if prop[p1-1] >0:
			dum=dum+prop[p1-1]
			n=n+1
		else:
			prop[p1-1]=-1.
		if prop[p2-1] >0:
			dum=dum+prop[p2-1]
			n=n+1
		else:
			prop[p2-1]=-1.
		if prop[p3-1] >0:
			dum=dum+prop[p3-1]
			n=n+1
		else:
			prop[p3-1]=-1.
		avg = dum/(float(n)+1.e-15)
		return prop, avg

	def reservoir(self):
		'''
		Take reservoir data from geomec (self.reservoirpoints, self.reservoirtriangles
		and self.reservoirpars), generate a surface trimesh (trim.trimesh) and 
		calculate reservoir attributes for each triangle in the trimesh. Plot results.
		'''
		try:

			self.var_thickness='dz' #FIXME: is it a literal or an index?
			# KB: Geomec returns N, E, z, not x, y, z. Change it here.
			self.reservoirpoints1 = np.array( self.reservoirpoints)
			self.reservoirpoints[:,0] = self.reservoirpoints1[:,1]
			self.reservoirpoints[:,1] = self.reservoirpoints1[:,0]

			self.resgrid=True
			self.inverted=False
         
			if self.subsgrid:
				self.b_construct['state'] = 'normal'

			zco=self.reservoirpoints[:,2]

			thick=self.reservoirpars[:,0]
			pr = self.reservoirpars[:,1]
			ym = self.reservoirpars[:,2]
			pres=self.reservoirpars[:,3]
			#logging.debug("type(thick): {}, type(self.reservoirpars): {}".format(type(thick), type(self.reservoirpars)))
			self.shiftxres=min(self.reservoirpoints[:,0])
			self.shiftyres=min(self.reservoirpoints[:,1])
			self.scalexres=max(self.reservoirpoints[:,0])-min(self.reservoirpoints[:,0])
			self.scaleyres=max(self.reservoirpoints[:,1])-min(self.reservoirpoints[:,1])
			self.scaleres=max([self.scalexres,self.scaleyres])

			lowest=1000
			highest=0
			for tri in self.reservoirtriangles:
				for p in tri:
					if p > highest:
						highest=p
					if p < lowest:
						lowest=p

			trim.trimesh.initiate(self.reservoirpoints,self.reservoirtriangles)

			self.x0=np.zeros((trim.trimesh.nTri,))

			nt = trim.trimesh.nTri
			avdepth = np.zeros(nt)
			avthick= np.zeros(nt)
			avpres = np.zeros(nt)
			avpr = np.zeros(nt)
			avym = np.zeros(nt)
			avcm = np.zeros(nt)
			for tri in range(trim.trimesh.nTri):
				p1=trim.trimesh.pTris[tri,0]
				p2=trim.trimesh.pTris[tri,1]
				p3=trim.trimesh.pTris[tri,2]
				p = [p1, p2, p3]
				
				# Assign average depth per triangle
				avdepth[tri] = (zco[p1-1]+zco[p2-1]+zco[p3-1])/3.

				# Assign average thickness per triangle
				thick, _avg = self.calc_triprop(thick, p)
				avthick[tri] = _avg

				pres, _avg = self.calc_triprop(pres, p)
				avpres[tri] = _avg

				pr, _avgpr = self.calc_triprop(pr, p)
				avpr[tri] = _avgpr

				ym, _avgym = self.calc_triprop(ym, p)
				avym[tri] = _avgym

				_avgcm = ((1.-2.*_avgpr) * (1.+_avgpr)) / ( _avgym * (1.-_avgpr) )   
				avcm[tri] = _avgcm

			avH=sum(avthick)/len(avthick)
			thick[thick<0.]=avH		   
			avP=sum(avpres)/len(avpres)
			pres[pres<0.]=avP

			avPR_=sum(avpr)/len(avpr)
			pr[pr<0.]=avPR_

			avYM_=sum(avym)/len(avym)
			ym[ym<0.]=avYM_

			self.avthick=np.array(avthick)
			self.avdepth=np.array(avdepth)
			self.avpres=np.array(avpres)
			self.prevpres = self.avpres
			self.avpr=np.array(avpr)
			self.avym=np.array(avym)
			self.avcm=np.array(avcm)
			self.zco=np.array(zco)

			self.reservoirpatches=[]
			for tri in range(trim.trimesh.nTri):
			   node1=trim.trimesh.pTris[tri,0]
			   node2=trim.trimesh.pTris[tri,1]
			   node3=trim.trimesh.pTris[tri,2]
			   poly=Polygon(np.array([[trim.trimesh.pnodes[node1-1,0],trim.trimesh.pnodes[node1-1,1]],
						   [trim.trimesh.pnodes[node2-1,0],trim.trimesh.pnodes[node2-1,1]],
						   [trim.trimesh.pnodes[node3-1,0],trim.trimesh.pnodes[node3-1,1]]]), True)
			   self.reservoirpatches.append(poly)
			self.textU.insert(1.0,'Reservoir loaded -- Next step: "Fill" Meas. Disp.\n','OK')
			self.setlimits()

			self.plotreservoir()

		except:
			helper.handle_exception()



	def subsidence(self, gm_results=False):
		''' 
     Process displacement data, either measured displacement from a point data 
     file that is loaded in the geomec data storage (gm_results = False) or 
     modelled displacement data from Geomec results (gm_results = True).
     Geomec returns:
        elems: the triangle ID (in trim.trimesh) in which the point lies.
        z: z-coordinate of the point.
        wdat:  a weight (not used)
        subs:  [dx, dy, dz] displacement data
        header: header labels (not used)
     Currently the original displacement data (x, y, z) is mapped to the mesh 
     in Geomec, to the center point of the triangle in which the point resides.
     The subs (dx, dy, dz) data is interpolated to this center point location.
     Only the element ID is given to the IT. Here, the center point x and y 
     coords are loaded.
     In a next version, the IT should simply receive the true x, y, z, subs data 
     from Geomec.
     self.subs is processed and returned as a 1-D array.
     If receiving modelled displacement from Geomec, the residual displacement 
     is calculated and returned to the IT.
     '''
		try:
			self.getinput()
			# Get x,y coordinates for the displacement points.
			self.xirr = np.zeros([len(self.elems),1])
			self.yirr = np.zeros([len(self.elems),1])
			for i in range(len(self.elems)):
				tri = self.elems[i]   
				node1=trim.trimesh.pTris[tri,0]
				node2=trim.trimesh.pTris[tri,1]
				node3=trim.trimesh.pTris[tri,2]
				x=(trim.trimesh.pnodes[node1-1,0]+trim.trimesh.pnodes[node2-1,0]+trim.trimesh.pnodes[node3-1,0])/3.
				y=(trim.trimesh.pnodes[node1-1,1]+trim.trimesh.pnodes[node2-1,1]+trim.trimesh.pnodes[node3-1,1])/3.
				self.xirr[i] = x
				self.yirr[i] = y

			self.subsign=self.inputs['Subsidence sign']
			if not gm_results:
				# If loading measured displacement, ensure that negative dz (i.e. subsidence) has a - sign.				
				# Note these are switched to be in line with Geomec, where subsidence is positive.
				# Geomec positive means depletion, so strain = negative
				if self.subsign=='+':
					self.sign=-1.
				# Geomec negative means exhumation, so strain = positive
				elif self.subsign=='-':
					self.sign=1.
				else:
					self.sign=0.
					self.textU.insert(1.0,'ERROR: sign is either + or -\n','ERROR') 
			else:
				# If loading modelled displacement, subsidence is returned as positive. Switch this:
				self.sign = -1.

			self.xsubs = self.subs[:,0]
			self.ysubs = self.subs[:,1]        
			# From this point onwards, zsubs is always negative for subsidence.
			self.zsubs = self.subs[:,2] * self.sign

			self.usex = False
			self.usey = False
			self.usez = False

			if np.average(self.subs[:,0]) > -9000.:
				self.usex = True
			if np.average(self.subs[:,1]) > -9000.:
				self.usey = True
			if np.average(self.subs[:,2]) > -9000.:
				self.usez = True

			# Inverted subsidence data, set subsgrid=True
			self.subsgrid=True
			# New subsidence data, set inverted=False
			self.inverted=False
		
			if self.resgrid:
				if gm_results:
					self.textU.insert(1.0,'Residual displacement calculated, run inversion\n','OK')
				else:
					self.textU.insert(1.0,'Forward operator should be (re)constructed\n','Warn')
					self.b_construct['state'] = 'normal'
			else:
				self.textU.insert(1.0,'Please import reservoir grid\n')
			self.textU.tag_configure('Warn', background='yellow', font='helvetica 6 bold', relief='raised')

			# logging.debug('self.subs before concatenate: {} (self.usex = {}, self.usey = {}, self.usez = {})'.format(self.subs, self.usex, self.usey, self.usez))
			# KB: This was initially in construct(), but needs to be updated every time
			# new subsidence data is loaded.
			if self.usex:
				if self.usey:
					if self.usez:
						self.subs=np.concatenate((self.xsubs,self.ysubs,self.zsubs))
					else:
						self.subs=np.concatenate((self.xsubs,self.ysubs))
				else:
					if self.usez:
						self.subs=np.concatenate((self.xsubs,self.zsubs))
					else:
						self.subs=self.xsubs
			else:
				if self.usey:
					if self.usez:
						self.subs=np.concatenate((self.ysubs,self.zsubs))
					else:
						self.subs=self.ysubs
				else:
					if self.usez:
						self.subs=self.zsubs
			#logging.debug('self.subs after concatenate (should be negative dz for subs): {}'.format(self.subs))
       # From this point, self.subs changed from [dx dy dz] to [disp]
       # This should always be a negative number.
       # If this is loading of measured displacement:
			if not gm_results: 
				# Loading measured displacement
				# Store measured displacement to calculate residual later on:
				self.subs_initial = np.array(self.subs) 
				# Keep track of average displacement to see improvements per iteration
				self.avs = [np.average(self.subs_initial)]
				# Define self.dsubs for plotting (residual) surface displacement. 
				self.dsubs_initial = np.array(self.zsubs)
				self.dsubs = self.dsubs_initial
				# Fix the colorbar for displacement to allow comparing different iterations.
				self.dd_min = min(self.dsubs)
				self.dd_max = max(self.dsubs)
				# If all displacement is negative, fix the upper limit to 0:
				if self.dd_max < 0.:
					self.dd_max = 0.
			else:
				# Calculate the residual between modelled (self.subs) and meausured
				# displacement (self.subs_initial, and use this as new subs for next iteration)
				try:
					self.subs_modelled_cumulative += self.subs
					self.zsubs_modelled_cumulative += self.zsubs
				except:
					self.subs_modelled_cumulative = self.subs
					self.zsubs_modelled_cumulative = self.zsubs
				#logging.debug('self.subs, self.subs_initial, self.subs_modelled_cumulative')
				self.subs = self.subs_initial - self.subs_modelled_cumulative
				self.dsubs = self.dsubs_initial - self.zsubs_modelled_cumulative
				
				self.avs.append(np.average(self.subs))
				self.sub9.clear()
				self.sub9.plot(range(len(self.avs)),self.avs)


			self.shiftxsurf=min(self.xirr)
			self.shiftysurf=min(self.yirr)
			self.scalexsurf=max(self.xirr)-min(self.xirr)
			self.scaleysurf=max(self.yirr)-min(self.yirr)
			self.scalesurf=max([self.scalexsurf,self.scaleysurf])

			if self.usex or self.usey or self.usez:
				
				self.setlimits()
				self.plotobservation()
				self.b_construct['state'] = 'normal'
				
			else:
				self.textU.insert(1.0,'ERROR: indicate at least 1 displacement\n','ERR')
				self.textU.tag_configure('ERR', background='red', font='helvetica 6 bold', relief='raised')
				self.subsgrid=False

		except:
			helper.handle_exception()

	def construct(self):
		'''
		Check if displacement and reservoir data are loaded. If yes, construct 
		the forward operator (makesystem())
		'''
		try:
			if self.subsgrid:
				if self.resgrid:
					self.makesystem()
					self.enable=True
					# Created forward constructor, enable execution of inversion
					self.b_execute['state'] = 'normal'
				else:
					self.textU.insert(1.0,'Missing reservoir grid!!\n','highlight')
			else:
				self.textU.insert(1.0,'Missing observation grid!!\n','highlight')
			self.textU.tag_configure('highlight', background='red', font='helvetica 6 bold', relief='raised')
		except:
			helper.handle_exception()

	def doit(self):
		'''
		Load the inversion settings (getinput()) and execute the inversion (inversion())
		'''
		try:
			self.getinput()
			self.inversion()
		except:
			helper.handle_exception()

	def makesystem(self):
		'''
		Construct the forward operator:
		As part of the inversion workflow, take the trim.trimesh generated in the
		reservoir() function and the displacement data (subs). 
		Uses:
		- Average reservoir thickness (self.avthick)
		- Displacement data coordinates (xirr, yirr, zirr)
		- Reservoir data z values (zco)
		- Reservoir trimesh
		Only needs to run if model geometry is changed.
     
		Note that I have split the generation of Az, Ax, Ay (only based on geometry)
		from the concatenate subs, as the latter needs to be done every time the subs 
		values change, but the A values stay constant.
		'''

		try:
			Az,Ax,Ay=nu.quadr(trim.trimesh,self.zco,self.avthick,self.xirr,self.yirr,self.zirr,4,2)

			# use this to get volumetric strain:
			self.scale1=np.diag(1./np.array(self.avthick)*0.+1.)
			# use this to get reservoir compaction/square meter:
			#self.scale1=np.diag(1./np.array(self.avthick)*1.+0.)

			self.scale_disp=self.avthick*1.
		
			self.scale2=np.diag(1./np.sqrt(trim.trimesh.area))
			#self.scale2=np.diag(1./trim.trimesh.area)

			if self.usex:
				if self.usey:
					if self.usez:
						A=np.concatenate((Ax,Ay,Az),axis=0)
					else:
						A=np.concatenate((Ax,Ay),axis=0)
				else:
					if self.usez:
						A=np.concatenate((Ax,Az),axis=0)
					else:
						A=Ax
			else:
				if self.usey:
					if self.usez:
						A=np.concatenate((Ay,Az),axis=0)
					else:
						A=Ay
				else:
					if self.usez:
						A=Az
			# Sometimes A is nested in another array.
			if len(A) == 1:
				A = np.array(A[0])
			#logging.debug("len(A): {}, len(self.scale1): {}, len(self.scale2): {}".format(len(A), len(self.scale1), len(self.scale2)))
			#logging.debug("A: {}, self.scale1: {}, self.scale2: {}".format(A, self.scale1, self.scale2))
			self.A=np.dot(A,self.scale1)
			#logging.debug("len(self.A): {}, self.A: {}".format(len(self.A), self.A))
			self.A2=np.dot(self.A,self.scale2)	
			#logging.debug("len(self.A2): {}, self.A2: {}".format(len(self.A2), self.A2))
			self.textU.insert(1.0,'Forward operator constructed. Next step: Run inversion (INVERT)\n','OK')
			self.textU.tag_configure('OK', background='green', font='helvetica 6 bold', relief='raised')
			self.b_construct['state'] = 'disabled'

		except:
			helper.handle_exception()

	def inversion(self):
		'''
		Do the inversion, using output from makesystem() and the displacement
		data.
		'''

		try:
			self.inverted=True

			frac=float(self.inputs['reduction factor'])/100.
			self.nit=int(self.inputs['internal iterations'])
			#logging.debug("frac in def inverison: {}".format(frac))
			# External iterations:
			self.nrw=int(self.inputs['external iterations'])
			self.reweight=int(self.inputs['reweight iterations\noutlier detection'])
			self.mc=1.        

			if self.enable:

				wdat=np.zeros((len(self.subs),))+1.
				#logging.debug("wdat at beginning: {}".format(wdat))

				for nnn in range(self.reweight):
					#print nnn
				
					extra=np.zeros((len(self.subs),))
			
					# KB This is the inversion
					rec,wt,extra,wtt=cg.lsqr(self.x0,self.A2,self.subs,np.zeros((len(self.subs),)),self.nit,self.nrw,0.1,1e-2,self.scale2,np.sqrt(wdat))
					# self.x0 = array of zeros with the length of trimesh
					# self.A2 = self.A2=np.dot(self.A,self.scale2)
					# where self.A = quadratic forward operator
					# self.scale2 = scale factor to calculate volume weighting: self.scale2=np.diag(1./np.sqrt(trim.trimesh.area))
					# self.subs = displacement values
					# self.nit = internal iterations
					# self.nrw = external iterations
				
					self.resolution=wt[len(rec)-1]

					rec1=rec[len(rec)-1]

					# scale back the inverted parameters
					rec_par=np.dot(self.scale2,rec1)
					#logging.debug("self.A: KEVIN: {}".format(rec_par))

					self.rec_par=1.*rec_par/float(self.mc)
					#logging.debug("self.rec_par: KEVIN: {}".format(self.rec_par))
					# KB: if this is the first run, store the 
					#     color range limits for next runs (reservoir strain).
					if not self.setrec_parlimits:
						self.rec_par_min = min(self.rec_par)
						self.rec_par_max = max(self.rec_par)
						self.setrec_parlimits = True
					#logging.debug("len(self.A): {}".format(len(self.A[0])))
					#logging.debug("len(self.rec_par): {}".format(len(self.rec_par)))
					#logging.debug("type(self.A): {}, type(self.rec_par): {}".format(type(self.A), type(self.rec_par)))
					#logging.debug("len(self.A[0]): {}, len(self.rec_par): {}, self.A: {}".format(len(self.A[0]),len(self.rec_par),self.A))
					self.rec_subs=np.dot(self.A,self.rec_par)
					#logging.debug("len(self.rec_subs): {}, self.rec_subs: {}".format(len(self.rec_subs), self.rec_subs))
					self.outliers=wdat
					wdat=outlierdetect(self.rec_subs,self.subs,frac)
					self.errtot=[mt.sqrt(sum(self.subs*self.subs*self.outliers)/sum(self.outliers)),]
					self.indxtot=[0,]
					self.energy=[]
					for lll in range(len(rec)):
						self.indxtot.append(lll+1)
						rec0=rec[lll]
						rec_par=np.dot(self.scale2,rec0)
						energy=rec_par*rec_par
						self.energy.append(energy)
						err=np.dot(self.A,rec_par)-self.subs
						self.errtot.append(mt.sqrt(sum(err*err*self.outliers)/sum(self.outliers)))

				self.plotresults()

				self.b_setdep['state'] = 'active'  

			else:
				self.textU.insert(1.0,'Forward operator should be (re)constructed first\n','highlight')
		except:
			helper.handle_exception()

	def plotresults(self):
		'''
		Plot inversion results:
		sub1 = inverted strain/compaction
		sub2 = geomec output
		sub3 = displacement error
		sub7 = detected outliers
		sub8 = RMS error
		'''
		try:
			self.textU.insert(1.0,'Displacement inverted, set depletion (SET DEPL.)\n','OK')
			self.textU.tag_configure('OK', background='green', font='helvetica 6 bold', relief='raised')

			ss=np.ones((len(self.xirr),))*20.

			self.sub1.clear()
			self.sub2.clear()
			self.sub3.clear()
			self.sub7.clear()
			self.sub8.clear()
			try:
				self.cbar1.remove()
			except:
				pass
			try:
				self.cbar2.remove()
			except:
				pass
			try:
				self.cbar3.remove()
			except:
				pass

			if self.invert_for.get()=='Compaction':
				#logging.debug('len: {}; scale_disp: {}'.format(len(self.scale_disp),self.scale_disp))
				#logging.debug('len: {}; self.avpr: {}'.format(len(self.avpr),self.avpr))
				weight=self.scale_disp*mt.pi/(1.-self.avpr)
				self.sub1.set_title('Inverted reservoir compaction',fontsize=12)
			else:
				weight=1.
				self.sub1.set_title('Inverted reservoir strain',fontsize=12)

			# Plot reservoir deformation
			p2=PatchCollection(self.reservoirpatches,cmap=matplotlib.cm.gist_rainbow,edgecolor='none')
			p2.set_array(np.array(self.rec_par)*weight)
			# KB: keep colors fixed based on the first iteration
			p2.set_clim([self.rec_par_min, self.rec_par_max])
			bla=self.sub1.add_collection(p2)

			# Plotting Geomec data to sub2
			p2=PatchCollection(self.reservoirpatches,cmap=matplotlib.cm.gist_rainbow,edgecolor='none')

			# Based on selected output format, plot Geomec data:
			if self.cb_type.current() == 2:
				self.sub2.set_title('$\Delta$P for GEOMEC [MPa]',fontsize=12)
				_plotsub2 = (self.rec_par / self.avcm)
			elif self.cb_type.current() == 1:
				self.sub2.set_title('Cm for GEOMEC [1/MPa]',fontsize=12)  
				_plotsub2 = (self.rec_par / self.avpres) + self.avcm
			else:
				self.sub2.set_title('Strain for GEOMEC [-]',fontsize=12)
				_plotsub2 = -self.rec_par

			# Plot parameter resolution
			p2=PatchCollection(self.reservoirpatches,cmap=matplotlib.cm.gist_rainbow,edgecolor='none')
			p2.set_array(_plotsub2)
			bla2=self.sub2.add_collection(p2)

			nn=len(self.outliers)/len(self.xirr)
			nx=len(self.xirr)
			wdat=np.ones((nx,))
			for m in range(nn):
				wdat=wdat*self.outliers[m*nx:(m+1)*nx]
			wdat2=wdat*1.
			self.mask=wdat2
			wdat[wdat>0]=np.nan
			self.sub7.scatter(self.xirr,self.yirr,s=ss,c=wdat,edgecolor='k',vmin=0.,vmax=1)
			self.sub8.plot(self.indxtot,self.errtot)
			self.sub3.scatter(self.subs,self.rec_subs,s=ss,c=wdat2,vmin=0.,vmax=1.)
			ax1=self.fig.add_axes(self.ax1)
			ax2=self.fig.add_axes(self.ax2)

			#self.cbar1=self.fig.colorbar(bla, cax=ax1,format='%.0e')
			self.cbar1=self.fig.colorbar(bla, cax=ax1)
			self.cbar2=self.fig.colorbar(bla2, cax=ax2)

			self.plotobservation()

			self.setplotpars()

			self.display.show()
		except:
			helper.handle_exception()

	def plotreservoir(self):
		'''
		Plot the loaded reservoir surface with its attribute (e.g. thickness, depth)
		'''
		try:
			self.sub4.clear()
			try:
				self.cbar4.remove()
			except:
				pass

			# KB 21-7: avthick and avdepth have large # of decimals, that impacts plotting.
			# round those for plotting only.
			# ['Depth','Thickness','Poisson\'s ratio','Young\'s modulus','Initial pore pressure']    
			if self.cb_show.current()==0:
				_prop = np.around(self.avdepth,1)
			elif self.cb_show.current()==1:
				_prop = np.around(self.avthick,1)
			elif self.cb_show.current()==2:
				_prop = np.around(self.avpr,3)
			elif self.cb_show.current()==3:
				_prop = np.around(self.avym,3)
			elif self.cb_show.current()==4:       
				_prop = np.around(self.avpres,1)
			elif self.cb_show.current()==5:       
				_prop = np.around(self.avcm,1)
			else: # show depth by default
				_prop = np.around(self.avdepth,1)

			_title = str(self.cb_show.get())
			p1=PatchCollection(self.reservoirpatches,cmap=matplotlib.cm.gist_rainbow,edgecolor='none')
			p1.set_array(_prop)
			bla1=self.sub4.add_collection(p1)

			ax4=self.fig.add_axes(self.ax4)
			self.sub4.set_title(_title,fontsize=12)

			self.cbar4=self.fig.colorbar(bla1, cax=ax4)

			self.setplotpars()
		except:
			helper.handle_exception()

	def plotobservation(self):
		'''
		Plot the measured input displacement or the modelled residual displacement.
		'''
		try:
			if self.inverted:
				mask=self.mask
			else:
				mask=np.ones((len(self.xirr),))

			ss=np.ones((len(self.xirr),))*20.

			self.sub5.clear()
			try:
				self.cbar5.remove()
			except:
				pass

			dd=self.dsubs*1.
			#logging.debug("self.dsubs in plotobservation(): {}".format(self.dsubs))
			dd[mask<1]=np.nan

			scats=self.sub5.scatter(self.xirr,self.yirr,s=ss,c=dd,vmin=self.dd_min,vmax=self.dd_max,edgecolor='none',cmap=matplotlib.cm.gist_rainbow_r)

			ax5=self.fig.add_axes(self.ax5)

			self.cbar5=self.fig.colorbar(scats, cax=ax5)
			self.sub5.set_title('Displacement for inversion [m]',fontsize=12)

			self.setplotpars()
		except:
			helper.handle_exception()

	def setlimits(self):
		'''
		Helper function to find the lateral extents of the plotted data.
		'''
		
		try:
			if self.subsgrid:
				minxsurf=self.shiftxsurf
				minysurf=self.shiftysurf
				maxxsurf=minxsurf+self.scalexsurf
				maxysurf=minysurf+self.scaleysurf
			else:
				minxsurf=self.shiftxres
				minysurf=self.shiftyres
				maxxsurf=minxsurf+self.scalexres
				maxysurf=minysurf+self.scaleyres

			if self.resgrid:
				minxres=self.shiftxres
				minyres=self.shiftyres
				maxxres=minxres+self.scalexres
				maxyres=minyres+self.scaleyres
			else:
				minxres=self.shiftxsurf
				minyres=self.shiftysurf
				maxxres=minxres+self.scalexsurf
				maxyres=minyres+self.scaleysurf

			self.minx=min(minxsurf,minxres)
			maxx=max(maxxsurf,maxxres)
			self.miny=min(minysurf,minyres)
			maxy=max(maxysurf,maxyres)
			scalex=maxx-self.minx
			scaley=maxy-self.miny
			self.scale=max(scalex,scaley)
		except:
			helper.handle_exception()

	def setplotpars(self):
		'''
		Helper function to set position, title and limits of plots:
		sub1 = inverted strain/compaction
		sub2 = geomec output
		sub3 = displacement error
		sub4 = reservoir properties
		sub5 = displacement
		sub6 = [removed]
		sub7 = detected outliers
		sub8 = RMS error
		sub9 = Mean residual
		'''
		try:
			self.sub1.set_xlim((self.minx,self.minx+self.scale))
			self.sub1.set_ylim((self.miny,self.miny+self.scale))
			self.sub2.set_xlim((self.minx,self.minx+self.scale))
			self.sub2.set_ylim((self.miny,self.miny+self.scale))
			self.sub3.set_xlim((min(self.rec_subs),max(self.rec_subs)))
			self.sub3.set_ylim((min(self.rec_subs),max(self.rec_subs)))
			self.sub4.set_xlim((self.minx,self.minx+self.scale))
			self.sub4.set_ylim((self.miny,self.miny+self.scale))
			self.sub5.set_xlim((self.minx,self.minx+self.scale))
			self.sub5.set_ylim((self.miny,self.miny+self.scale))
			self.sub7.set_xlim((self.minx,self.minx+self.scale))
			self.sub7.set_ylim((self.miny,self.miny+self.scale))
		
			self.sub3.set_title('Displacement error',fontsize=10)
			self.sub7.set_title('Detected outliers',fontsize=10)
			self.sub8.set_title('RMS error evolution',fontsize=10)
			self.sub9.set_title('Mean residual [m]',fontsize=10)

			self.sub1.set_position([.04,.055,.25,.4])
			self.sub2.set_position([.385,.055,.25,.4])
			self.sub4.set_position([.04,.55,.25,.4])
			self.sub5.set_position([.385,.55,.25,.4])

			self.sub3.set_position([.72,.78,.25*3./7.,.4*3./7.])
			self.sub7.set_position([.72,.295,.25*3./7.,.4*3./7.])
			self.sub9.set_position([.72,.055,.25*3./7.,.4*3./7.])
			self.sub8.set_position([.72,.55,.25*3./7.,.4*3./7.])

			if self.cultural:
				for m in range(len(self.cult)):
					coor=self.cult[m]
					ptype=self.culttype[m]
					if ptype=='line':
						self.sub5.plot(coor[:,0],coor[:,1],'k')
						self.sub1.plot(coor[:,0],coor[:,1],'k')
						self.sub2.plot(coor[:,0],coor[:,1],'k')
						self.sub7.plot(coor[:,0],coor[:,1],'k')
						self.sub4.plot(coor[:,0],coor[:,1],'k')
					else:
						self.sub5.plot(coor[:,0],coor[:,1],'ok')
						self.sub1.plot(coor[:,0],coor[:,1],'ok')
						self.sub2.plot(coor[:,0],coor[:,1],'ok')
						self.sub7.plot(coor[:,0],coor[:,1],'ok')
						self.sub4.plot(coor[:,0],coor[:,1],'ok')
			self.display.show()
		except:
			helper.handle_exception()

	def readcultural(self):
		'''
		Read cultural data: open line or point ascii data file and plot in IT.
		'''
		try:
			self.filename = tkF.askopenfilename(parent=None,initialdir=self.directory,title='Open Cultural file')
			self.directory=os.path.dirname(self.filename)

			fin=open(self.filename,'r')
			coor=[]
			for m in fin.readlines():
				line=m.strip().split()
				coor.append([float(line[0]),float(line[1])])
			coor=np.array(coor)

		
			types=['points','line']
			
			self.root = tk.Toplevel(self)
			self.root.geometry("%dx%d+%d+%d" % (500, 200, 200, 150))
			self.root.title("tk.Optionmenu as combobox")
			self.var_thickness = tk.StringVar(self.root)
			self.var_thickness.set('line')
			option1 = tk.OptionMenu(self.root, self.var_thickness, *types)
			option1.grid(sticky=tk.W+tk.N+tk.E,row=2,column=10,columnspan=1)

			l=tk.Label(self.root,text='filename:',width=10,anchor=tk.W,justify=tk.LEFT)
			l.grid(row=1,column=5)
			l=tk.Label(self.root,text=self.filename,width=100,anchor=tk.W,justify=tk.LEFT)
			l.grid(row=1,column=10,columnspan=5)

			l=tk.Label(self.root,text='plot type',width=10,anchor=tk.W,justify=tk.LEFT)
			l.grid(row=2,column=5)
			l=tk.Label(self.root,text='',width=10,anchor=tk.E,justify=tk.RIGHT)
			l.grid(row=2,column=13)

			self.wait_window(self.root)
			self.cultural=True
			self.cult.append(coor)
			self.culttype.append(self.var_thickness.get())
			self.setplotpars()
		except:
			helper.handle_exception()

	def saveresults( self ):	pass

def main():

	try:
		logging.basicConfig( filename=LOG_FILE, format='%(asctime)s %(message)s', level=logging.DEBUG )
		logging.debug("-------------------------------------------------------------------------------------------")

		root = tk.Tk()
		w = subsinversion( root )

		root.bind("<KeyRelease>", w.iface.key_release)

		w.mainloop()  
		w.quit()
		root.quit()

		#del tk
		#del np

		#GeomecInterface.send_cmd( GeomecInterface.Request_Id.Cmd_Quit ) #do it this way and not like this: w.send_req( GeomecInterface.Request_Id.Cmd_Quit )
		logging.debug("///////////////////////////////////////////////////////////////////////////////////////////")
	except:
		helper.handle_exception()

if __name__=='__main__':

	main()
