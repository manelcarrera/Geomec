import numpy as np

class Clase:

	class Pos:
		elem=0
		Wdat=1
		Subs=2