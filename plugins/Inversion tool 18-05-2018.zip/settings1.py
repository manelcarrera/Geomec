import logging
from geomec_interface import GeomecInterface as GI

settings1 = {
	'force_can' : True,
	'LINES' : 1, # key sentive so it must be in capital letters
	'loggging_level' : logging.DEBUG, # logging.CRITICAL logging.ERROR logging.WARNING logging.INFO logging.DEBUG

	'component'		: GI.Component.Z,
	'composite'		: GI.Composite.Displacement,
	'dep'			: GI.Depletion.Id.Last,
	'dep_output'	: GI.Depletion.Output.Branch,
	'prop_form'		: GI.Prop.Form.Thickness,
	'prop_mat'		: GI.Prop.Mat.PoissonsRatio,
	'prop_dep'		: GI.Prop.Dep.PorePressure,
	'ps_id'			: 0,
	'list'			: GI.List.Reservoir,
	'composite_idx'	: -1, # case: set_depletion with action == GI.Depletion.Action.Replace
	'mat_idx'		: -1,
	'mat_type'		: GI.Material.Model.Linear,
	'param_idx'		: 0,
	'param_value'	: 0
}