try:
	from Tkinter import Frame
	import Tkinter as tk
	import ttk
	import tkFileDialog as tkF
	#import math as mt				#FIXME
	#import numpy as np				#FIXME
	import os
	#import nucleus_unstructured as nu # nucleus of strain - Kees		#FIXME : -> import numpy
	#import trimesh as trim # trimesh functions of Kees					#FIXME
	#import cgschemes as cg # conjugate gradient scheme of Kees			#FIXME

	# Imports for plotting:
	import matplotlib				#FIXME
	from matplotlib.patches import Polygon
	from matplotlib.collections import PatchCollection
	from matplotlib import rcParams
	from matplotlib.figure import Figure
	from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg #, NavigationToolbar2TkAgg

	# Imports for the Geomec interface
	import logging
	import helper
	from workflow_IT1 import Workflow_IT1
	from workflow_IT2 import Workflow_IT2
	from geomec_interface import GeomecInterface as GI
	from widget_helper import WidgetHelper

	LOG_FILE="E:\IT_py.log"
except:
	LOG_FILE="E:\IT_py.log"
	import logging
	logging.basicConfig( filename=LOG_FILE, format='%(asctime)s %(message)s', level=logging.DEBUG )
	import helper
	helper.handle_exception()

def main():

	try:
		logging.basicConfig( filename=LOG_FILE, format='%(asctime)s %(message)s', level=logging.DEBUG )
		logging.debug("-------------------------------------------------------------------------------------------")
		logging.debug("///////////////////////////////////////////////////////////////////////////////////////////")
	except:
		helper.handle_exception()

if __name__=='__main__':
	main()
