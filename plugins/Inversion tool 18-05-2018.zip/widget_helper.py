from geomec_interface import GeomecInterface # GeomecInterface.Request_Id 
#from geomec_interface_ext import GeomecInterfaceExt # GeomecInterfaceExt.Request_Id 

import ttk #combobox

#from Tkinter import *
#from Tkinter import Frame
import Tkinter as tk

import helper

class WidgetHelper:

	def __init__(self, gui, iface ):
		self.gui=gui
		self.iface=iface

	def _create_lbl( self, _text, _row, _col ):
		l=tk.Label(self.gui,text=_text,width=10,anchor=tk.W,justify=tk.LEFT)
		l.grid(row=_row,column=_col)

	def _create_cb( self, _row, _col, _bind ):
		val = tk.StringVar()
		btn=ttk.Combobox( self.gui, textvariable=val )
		#self.cb_reservoir['values'] = ('Reservoir', 'Reservoir 2', 'Reservoir 3')
		#self.cb_reservoir.current(0)
		btn.grid(column=_col,columnspan=2,row=_row,sticky=tk.W)
		btn['state'] = 'active'
		btn.bind("<<ComboboxSelected>>", _bind )
		return (btn,val)

	def _create_btn( self, _text, _row, _col, _cmd ):

		#photo = ImageTk.PhotoImage(Image.open(path))
		#photo=PhotoImage(file="FF.gif")
		btn=tk.Button(self.gui,text=_text, command= _cmd ,width=5,height=1)
		#btn=Button(self.gui,text=_text, command= _cmd, image=photo)
		btn.grid(column=_col,columnspan=1,row=_row,sticky=tk.W)
		btn['state'] = 'active'

	def _create_line( self, _text_lbl, _text_btn, _text_btn2, _row, _callback, _cmd, _cmd2=False ):
		self._create_lbl( _text_lbl, _row, 4 )
		cb,cb_val = self._create_cb( _row, 5, _callback )
		self._create_btn( _text_btn, _row, 7, _cmd )
		if _cmd2:      
			self._create_btn( _text_btn2, _row, 8, _cmd2 )
		return cb, cb_val

	def _create_check_box( self, _row, _col, _width,_text ):

		var=tk.IntVar()
		ch=tk.Checkbutton(self.gui,text=_text,onvalue=1,offvalue=0,variable=var,width=_width,anchor=tk.W,justify=tk.LEFT)
		ch.var=var
		ch.grid(row=_row,column=_col,columnspan=1)
		return (ch,var)

	def _create_check_boxes( self, _row ):

		_width=3
		self.gui.ch_surface,self.gui.ch_surface_val	= self._create_check_box(_row,4,_width,'surf')
		self.gui.ch_dx,self.gui.ch_dx_val			= self._create_check_box(_row,5,_width,'dx')
		self.gui.ch_dy,self.gui.ch_dy_val			= self._create_check_box(_row,6,_width,'dy')
		self.gui.ch_dz,self.gui.ch_dz_val			= self._create_check_box(_row,7,_width,'dz')

		self.gui.ch_surface.select() 
		self.gui.ch_dz.select()

	def _create_check_boxes_res( self, _row ):

		_width=3

		self.gui.ch_res_dz,self.gui.ch_res_dz_val	= self._create_check_box(_row,4,_width,'thick')
		self.gui.ch_res_pr,self.gui.ch_res_pr_val	= self._create_check_box(_row,5,_width,'pr')
		self.gui.ch_res_ym,self.gui.ch_res_ym_val	= self._create_check_box(_row,6,_width,'ym')
		self.gui.ch_res_pp,self.gui.ch_res_pp_val	= self._create_check_box(_row,7,_width,'pp')

		self.gui.ch_res_dz.select()
		self.gui.ch_res_pr.select()
		self.gui.ch_res_ym.select()
		self.gui.ch_res_pp.select()

	def Pre_Cmd_Set_Depletion(self, _req):
		# Helper function: activate the run Geomec button when setting depletion.
		self.iface.send_req( _req )
		self.gui.b_rungm['state'] = 'active'      

	def Pre_Cmd_Get_Surface_List(self, _req):
		if self.ResListSelected: 
			self.iface.send_req( _req )
			self.ResSurfSelected = True
			self.gui.textU.insert(1.0,'Surface loaded -- Next step: "Get" Reservoir\n','OK')
		else:
			self.gui.textU.insert(1.0,'Select a reservoir formation first ("Fill")\n','ERROR')

	def Pre_Cmd_Get_Reservoir_List(self, _req):
		self.iface.send_req( _req )
		self.ResListSelected = True
		self.gui.textU.insert(1.0,'Reservoir list loaded -- Next step: "Fill" surface\n','OK')

	def Pre_Cmd_Get_Reservoir(self, _req):
		if self.ResListSelected and self.ResSurfSelected: 
			self.iface.send_req( _req )
			self.ResSelected = True
			self.gui.textU.insert(1.0,'Loading reservoir... please wait...\n','WARN')
		else:
			self.gui.textU.insert(1.0,'Select the top reservoir surface first ("Fill")\n','ERROR')

	def Pre_Cmd_Get_Measured_Displacement_List(self, _req):
		if self.ResSelected: 
			self.iface.send_req( _req )
			self.DispSelected = True         
			self.gui.textU.insert(1.0,'Displacement list loaded -- Next step: "Get" Meas. Disp.\n','OK')
		else:
			self.gui.textU.insert(1.0,'Load a reservoir first ("Get")\n','ERROR')

	def Pre_Cmd_Get_Measured_Displacement(self, _req):
		if self.DispSelected: 
			self.iface.send_req( _req )
			self.gui.textU.insert(1.0,'Displacement loaded -- Next step: CONSTRUCT operator\n','OK')
		else:
			self.gui.textU.insert(1.0,'Load the list of displacement data first ("Fill")\n','ERROR')

	def Pre_Cmd_Get_Displacement_List(self, _req):
		self.iface.send_req( _req )
		self.gui.textU.insert(1.0,'Displacement list loaded -- Next step: "Get"\n','OK')
		self.Geomec_Displacement_ReLoaded = True

	def Pre_Cmd_Get_Displacement(self, _req):
		if self.Geomec_Displacement_ReLoaded: 
			self.iface.send_req( _req )
			self.Geomec_Displacement_ReLoaded = False
			self.gui.b_execute['state'] = 'active'      
		else:
			self.gui.textU.insert(1.0,'Modelled displacement is already updated\n','ERROR')

	def create_widgets(self, row=1):

		try:
			self.ResSurfSelected = False
			self.ResSelected = False
			self.ResListSelected = False
			self.DispSelected = False
			self.Geomec_Displacement_ReLoaded = False

			self.gui.cb_res,self.gui.cb_res_val = self._create_line( 'Reservoir:',	'Fill',	'Get', row, 
				self.iface.cb_newselection, 
				lambda: self.Pre_Cmd_Get_Reservoir_List( GeomecInterface.Request_Id.Cmd_Get_Reservoir_List ),
				lambda: self.Pre_Cmd_Get_Reservoir( GeomecInterface.Request_Id.Cmd_Get_Reservoir ) )

			#surface: to select the top surface
			row+=1
			self.gui.cb_sur,self.gui.cb_sur_val = self._create_line( 'Surface:',	'Fill', '', row, 
				self.iface.cb_newselection, 
				lambda: self.Pre_Cmd_Get_Surface_List( GeomecInterface.Request_Id.Cmd_Get_Surface_List ) )

			# Plot reservoir property
			row+=1
			self._create_lbl('Plot:', row, 4)
			self.gui.cb_show,self.gui.cb_show_val = self._create_cb( row, 5, self.iface.cb_newselection )
			self.gui.cb_show['values'] = ['Depth','Thickness','Poisson\'s ratio','Young\'s modulus','Initial pore pressure','Compressibility']
			self.gui.cb_show.current( 0 )

			#measured displacement
			row+=1
			self.gui.cb_dis_meas,self.gui.cb_dis_meas_val = self._create_line( 'Meas. disp.:',	'Fill', 'Get', row, 
				self.iface.cb_newselection, 
				lambda: self.Pre_Cmd_Get_Measured_Displacement_List( GeomecInterface.Request_Id.Cmd_Get_Measured_Displacement_List ),
				lambda: self.Pre_Cmd_Get_Measured_Displacement( GeomecInterface.Request_Id.Cmd_Get_Measured_Displacement ) )

			#pore pressure / strain / compressibility
			row+=1
			self._create_lbl('Output:', row, 4)
			self.gui.cb_type,self.gui.cb_type_val = self._create_cb( row, 5, self.iface.cb_newselection )
			self.gui.cb_type['values'] = ['Strain','Compressibility','Pore pressure']
			self.gui.cb_type.current( 0 )

			#depletion
			#row+=1
			#self.gui.cb_dep,self.gui.cb_dep_val = self._create_line( 'Depletion:',		'Fill',	'Set', row, 
			#	self.gui.cb_newselection, 
			#	lambda: self.gui.send_req( GeomecInterface.Request_Id.Cmd_Get_Depletion_List ),
			#	lambda: self.Pre_Cmd_Set_Depletion(GeomecInterface.Request_Id.Cmd_Set_Depletion) )

			#modelled displacement
			row+=1
			self.gui.cb_dis,self.gui.cb_dis_val = self._create_line( 'Model disp.:',	'Fill', 'Get', row, 
				self.iface.cb_newselection, 
				lambda: self.Pre_Cmd_Get_Displacement_List( GeomecInterface.Request_Id.Cmd_Get_Displacement_List ),
				lambda: self.Pre_Cmd_Get_Displacement( GeomecInterface.Request_Id.Cmd_Get_Displacement ) )

			#checkboxes
			row+=1
			#self._create_check_boxes( row )
			#row+=1
			#reservoir
			#self._create_check_boxes_res( row )

			return row
		except:
			helper.handle_exception()

