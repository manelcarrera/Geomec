import logging

from geomec_interface import GeomecInterface # GeomecInterface.Request_Id 
from geomec_interface_ext import GeomecInterfaceExt # GeomecInterfaceExt.Request_Id 

#import numpy as np

import helper #handle_exception

from reservoir import Reservoir
from displacement import Displacement

class ResultsHandler():
	'''
	Handles the responses to a requests sent to Geomec.
	It keeps a pointer to the GUI.
	'''

	class Constants:
		LIST_DELIMITER = '*'

	def __init__( self, gui, iface ):
		self.gui = gui
		self.iface = iface

	def handle( self, _res ):

		try:
			logging.debug('   <--')
			logging.debug('handle:{}'.format(_res))
			cmd_id,res=_res
			logging.debug( 'cmd:{}'.format(GeomecInterface.Request_Id.name[ cmd_id ] ) )
			logging.debug( 'len(res):{} res[0]:{}'.format( len( res ), res[ 0 ] ) )

			if( isinstance(res, basestring) and res == "nok" ):
				logging.debug( 'res: NOK' )
				#ERROR_TEXT = """ERROR

				#Something goes wrong."""
				#self.iface.popup( ERROR_TEXT )

			else:
				logging.debug( 'res: not is NOK' )
				'''
				if cmd_id < 100:
					cmd_name = GeomecInterface.Request_Id.name[ cmd_id ]
				else: #ENTENDED CMD
					cmd_name = GeomecInterfaceExt.Request_Id.name[ cmd_id - 100 ]
				logging.debug( 'cmd:{}'.format( cmd_name ) )
				'''
				#res = _res[1:]
				#----------------------------------------------------------------------------------- Regular
				if cmd_id	== GeomecInterface.Request_Id.Cmd_Get_Reservoir_List:				self.set_reservoir_list(			res )
				elif cmd_id == GeomecInterface.Request_Id.Cmd_Get_Displacement_List:			self.set_displacement_list(			res )
				elif cmd_id == GeomecInterface.Request_Id.Cmd_Get_Depletion_List:				self.set_depletion_list(			res )
				elif cmd_id == GeomecInterface.Request_Id.Cmd_Get_Measured_Displacement_List:	self.set_measured_displacement_list( res )
				elif cmd_id == GeomecInterface.Request_Id.Cmd_Get_Reservoir:					self.set_reservoir(					res )
				elif cmd_id == GeomecInterface.Request_Id.Cmd_Get_Displacement:					self.set_displacement(				res )
				elif cmd_id == GeomecInterface.Request_Id.Cmd_Get_Measured_Displacement:		self.set_measured_displacement(		res )
				elif cmd_id == GeomecInterface.Request_Id.Cmd_Get_Material_Parameter:			self.set_material_parameter(		res )
				elif cmd_id == GeomecInterface.Request_Id.Cmd_Get_Surface_List:					self.set_surface_list(				res )
				elif cmd_id == GeomecInterface.Request_Id.Cmd_Get_Depletion:					pass
				elif cmd_id == GeomecInterface.Request_Id.Cmd_Set_Depletion:					pass
				elif cmd_id == GeomecInterface.Request_Id.Cmd_Run_Geomec:						pass
				#----------------------------------------------------------------------------------- Extended
				#elif cmd_id == GeomecInterfaceExt.Request_Id.Cmd_Get_Reservoir_From_File:		self.set_reservoir(					res )
				#elif cmd_id == GeomecInterfaceExt.Request_Id.Cmd_Get_Displacement_From_File:	self.set_measured_displacement(		res )
				#elif cmd_id == GeomecInterfaceExt.Request_Id.Cmd_Get_Generic:					pass
				else:																			pass
				#-----------------------------------------------------------------------------------
		except:
			helper.handle_exception()

	def fill_combo( self, res, combo ):

		try:
			list = res[ 0 ]
			elems = list.split( self.Constants.LIST_DELIMITER ) #list: tuple -> list[0]: first and only elem of the tuple

			logging.debug( elems )

			combo['values'] = elems
			combo.current( 0 )
		except:
			helper.handle_exception()

	def set_reservoir_list( self, res ):				self.fill_combo(res,self.gui.cb_res)
	def set_displacement_list( self, res ):				self.fill_combo(res,self.gui.cb_dis)
	def set_measured_displacement_list( self, res ):	self.fill_combo(res,self.gui.cb_dis_meas)
	def set_depletion_list( self, res ):				self.fill_combo(res,self.gui.cb_dep)
	def set_surface_list( self, res ):					self.fill_combo(res,self.gui.cb_sur)

	#-----------------------------------------------------------------------------------
	def set_reservoir( self, reservoir ):
	#-----------------------------------------------------------------------------------

		try:
			self.gui.reservoirpoints,self.gui.reservoirtriangles,self.gui.reservoirpars,self.gui.reservoirheader=reservoir
			#_,self.gui.reservoirtriangles,_,self.gui.reservoirheader=reservoir

			import numpy as np
			points=np.array(self.gui.reservoirpoints)
			x_min, y_min, z_min = points.min( axis=0 )
			x_max, y_max, z_max = points.max( axis=0 )
			logging.debug( 'x:{}-{} y:{}-{} z:{}-{}'.format( x_min, x_max, y_min, y_max, z_min, z_max ) )

			Reservoir.print_sizes( reservoir )
			#Reservoir.print_02( reservoir )
			#self.gui.reservoirpoints,self.gui.reservoirpars = Reservoir.transform( reservoir ) #points,pars:thickness
			self.gui.reservoir()
			
		except:
			helper.handle_exception()

	#-----------------------------------------------------------------------------------
	def set_displacement( self, displacement ):
	#-----------------------------------------------------------------------------------

		try:
			#logging.debug( displacement )
			#Displacement.print_sizes( displacement )
			#Displacement.print_02( displacement )
			self.gui.elems, self.gui.zirr, self.gui.wdat, self.gui.subs, self.gui.header = Displacement.transform( displacement )
			#logging.debug("In set_displacement, after run gm run, gm_results = True")
			#logging.debug("elems in set_displacement after gm run: {}".format(len(self.gui.elems)))       
			self.gui.subsidence(gm_results=True)
		except:
			helper.handle_exception()

	#-----------------------------------------------------------------------------------
	def set_measured_displacement( self, displacement ):
	#-----------------------------------------------------------------------------------

		try:
			#logging.debug( displacement )
			#Displacement.print_sizes( displacement )
			#Displacement.printKB_( displacement )   
			# KB Geomec supplies N E z
			self.gui.elems, self.gui.zirr, self.gui.wdat, self.gui.subs, self.gui.header = Displacement.transform( displacement )
			#self.gui.xirr, self.gui.yirr, self.gui.zirr, self.gui.wdat, self.gui.subs, self.gui.header = Displacement.transform( displacement )
			#logging.debug("In set_displacement, load disp, gm_results = False")
			self.gui.subsidence()
		except:
			helper.handle_exception()

	def set_material_parameter( self, val ):
		#self.gui.poisson_ratio_val=val #TODO:
		pass

	def set_depletion( self, val ):
		pass
	#-----------------------------------------------------------------------------------

def test_1():
	logging.basicConfig(	filename="c:\Temp\IT_py.log", 
							format='%(asctime)s %(message)s',
							level=logging.DEBUG)


	logging.debug("MCR")

	res=( 1,('Hola*Adios',) )
	cmd_id,params=res

	#logging.debug( res )

	#res = res[1:]

	logging.debug( 'res:{} params:{}'.format(res,params) )

	handler = ResultsHandler( None )

	handler.set_reservoir_list( params )

#test_1()

'''
import numpy as np
a = [ [ -708.97241211, -1801.56030273,   999.99993896 ] ]
logging.debug('a:{}'.format( a ) )

b = np.array( a )
logging.debug('b:{}'.format( b ) )

#a = [ [ 1, 2, 3 ] ]

# [ -662.73815918 -1835.17626953  1000.        ]
# [ -662.18603516 -1793.53405762  1000.        ] ]
'''


'''
import numpy as np

a0 = ['x','y','z']

a = np.array( a0 )
logging.debug('a:{}'.format( a ) )

b = a[:,0:2]
logging.debug('b:{}'.format( b ) )
'''

		