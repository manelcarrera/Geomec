from geomec_interface import GeomecInterface
from geomec_interface_ext import GeomecInterfaceExt
import threading
import logging
#import helper #handle_exception

'''
http://stackoverflow.com/questions/16745507/tkinter-how-to-use-threads-to-preventing-main-event-loop-from-freezing
'''

class ThreadedTask(threading.Thread):

	def __init__(self, queue, req ):

		threading.Thread.__init__(self)
		self.queue = queue
		self.req=req

	def run(self):

		logging.debug( 'ThreadedTask : cmd:{}'.format( self.req ) )
		GeomecInterface.send_cmd( self.req )
		res=GeomecInterface.get_result()
		self.queue.put( res )
			

	'''
	def run(self):

		logging.debug( 'ThreadedTask : cmd:{}'.format( self.req ) )

		try:
			cmd_id = self.req[ 0 ]

			if cmd_id > 99:
				filename = self.req[ 1 ]
				if cmd_id == GeomecInterfaceExt.Request_Id.Cmd_Get_Displacement_From_File:
					res=GeomecInterfaceExt.displacement( filename )
				if cmd_id == GeomecInterfaceExt.Request_Id.Cmd_Get_Reservoir_From_File:
					res=GeomecInterfaceExt.reservoir( filename )
				else:
					params=self.req[ 1 ]
					res=GeomecInterfaceExt.func( params )
			else:
				GeomecInterface.send_cmd( self.req )
				res=GeomecInterface.get_result()

			self.queue.put( res )

		except:
			helper.handle_exception()
		'''
