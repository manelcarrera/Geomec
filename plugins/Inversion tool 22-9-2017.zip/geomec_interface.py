#import sys
import geomec
import logging
import numpy as np #FIXME: remove

class GeomecInterface:

	class Request_Id:

		Cmd_Get_Reservoir_List				= 0
		Cmd_Get_Displacement_List			= 1
		Cmd_Get_Depletion_List				= 2
		Cmd_Get_Reservoir					= 3
		Cmd_Get_Displacement				= 4
		Cmd_Get_Depletion					= 5
		Cmd_Run_Geomec						= 6
		Cmd_Save_Displacement				= 7
		Cmd_Set_Depletion					= 8
		Cmd_Quit							= 9
		Cmd_Remove_Depletion				= 10
		Cmd_Get_Material_Parameter			= 11
		Cmd_Get_Measured_Displacement_List	= 12
		Cmd_Get_Measured_Displacement		= 13
		Cmd_Get_Surface_List				= 14
		Cmd_None							= 15

		name = (
			'Cmd_Get_Reservoir_List',				# 0
			'Cmd_Get_Displacement_List',			# 1
			'Cmd_Get_Depletion_List',				# 2
			'Cmd_Get_Reservoir',					# 3
			'Cmd_Get_Displacement',					# 4
			'Cmd_Get_Depletion',					# 5
			'Cmd_Run_Geomec',						# 6
			'Cmd_Save_Displacement',				# 7
			'Cmd_Set_Depletion',					# 8
			'Cmd_Quit',								# 9
			'Cmd_Remove_Depletion',					# 10
			'Cmd_Get_Material_Parameter',			# 11
			'Cmd_Get_Measured_Displacement_List',	# 12
			'Cmd_Get_Measured_Displacement',		# 13
			'Cmd_Get_Surface_List',					# 14
			'Cmd_None'								# 15
		)


	#-------------------------- send: IT -> GM
	@staticmethod
	def send_cmd( cmd ):
		geomec.send_cmd( cmd )

	#-------------------------- get: II <- GM
	@staticmethod
	def get_result():
		return geomec.get_result()

	#-------------------------- show gui: GM -> IT
	@staticmethod
	def gui_it():
		import inversion_GUI12_f
		inversion_GUI12_f.main()