import logging
import Queue
from results_handler import ResultsHandler
from widget_helper import WidgetHelper
from threaded_task import ThreadedTask
from geomec_interface import GeomecInterface # GeomecInterface.Request_Id 
from geomec_interface_ext import GeomecInterfaceExt # GeomecInterfaceExt.Request_Id 
import numpy as np
import helper
import ttk # Progress bar
import Tkinter as tk # tk.CENTER

class Settings:
	Displacement	= 0
	Poissons_Ratio	= 1
	Youngs_Modulus	= 2
	Pore_Pressure	= 3

class Params:
	Reservoir_Idx				= 0
	Depletion_Idx				= 1
	Displacement_Idx			= 2
	Type_Idx					= 3
	Measured_Displacement_Idx	= 4
	Surface_Idx					= 5
	Component_X					= 6
	Component_Y					= 7
	Component_Z					= 8
	Is_Surface					= 9

class Interface():

	#--------------------------------------------
	def __init__( self, gui ):
	#--------------------------------------------

		self.gui = gui

		self.results_handler = ResultsHandler( gui, self )
		self.is_processing_task = False
		self.POLLING_INTERVAL=100


	#--------------------------------------------
	def check_data( self, cmd_id, params, settings ):
	#--------------------------------------------
		try:
			ND = -1 # NOT DEFINED
			# lists : no need to be checked
			if cmd_id in (	GeomecInterface.Request_Id.Cmd_Get_Reservoir_List,
							GeomecInterface.Request_Id.Cmd_Get_Depletion_List,
							GeomecInterface.Request_Id.Cmd_Get_Displacement_List,
							GeomecInterface.Request_Id.Cmd_Get_Measured_Displacement_List,
							GeomecInterface.Request_Id.Cmd_Run_Geomec ):
				return True
			# reservoir
			elif cmd_id == GeomecInterface.Request_Id.Cmd_Get_Reservoir:
				if params[ Params.Reservoir_Idx ] == ND or params[ Params.Surface_Idx ] == ND: 
					return False
				else: 
					return True
			elif cmd_id == GeomecInterface.Request_Id.Cmd_Get_Surface_List:
				if params[ Params.Reservoir_Idx ] == ND:
					return False
				else:
					return True
			# displacements
			elif cmd_id == GeomecInterface.Request_Id.Cmd_Get_Displacement:
				if params[ Params.Displacement_Idx ] == ND:
					return False
				else:
					return True
			elif cmd_id == GeomecInterface.Request_Id.Cmd_Get_Measured_Displacement:
				if params[ Params.Measured_Displacement_Idx ] == ND:
					return False
				else:
					return True
			# depletions
			elif cmd_id == GeomecInterface.Request_Id.Cmd_Set_Depletion:
				if params[ Params.Depletion_Idx ] == ND or params[ Params.Type_Idx ] == ND:
					return False
				else:
					return True
			elif cmd_id == GeomecInterface.Request_Id.Cmd_Remove_Depletion:
				if params[ Params.Depletion_Idx ] == ND:
					return False
				else:
					return True
			# not implemented cmd's
			#elif cmd_id == GeomecInterface.Request_Id.Cmd_Get_Depletion: 
			#elif cmd_id == GeomecInterface.Request_Id.Cmd_Get_Material_Parameter:

			return False;

		except:
			helper.handle_exception()

	#--------------------------------------------
	def data( self ):
	#--------------------------------------------
		try:
			NOT_DEFINED_INT		= -1
			#NOT_DEFINED_DOUBLE	= -1.0

			# params:
			# combos
			res_idx			= self.gui.cb_res.current() if self.gui.cb_res.get() else NOT_DEFINED_INT
			#dep_idx			= self.cb_dep.current() if self.cb_dep.get() else NOT_DEFINED_INT
			dis_idx			= self.gui.cb_dis.current() if self.gui.cb_dis.get() else NOT_DEFINED_INT
			type_idx		= self.gui.cb_type.current() if self.gui.cb_type.get() else NOT_DEFINED_INT
			meas_dis_idx	= self.gui.cb_dis_meas.current() if self.gui.cb_dis_meas.get() else NOT_DEFINED_INT
			sur_idx			= self.gui.cb_sur.current() if self.gui.cb_sur.get() else NOT_DEFINED_INT
			self.type_idx = type_idx
			# check-boxes
			#is_surface	= self.gui.ch_surface_val.get()
			#is_dx		= self.gui.ch_dx_val.get()
			#is_dy		= self.gui.ch_dy_val.get()
			#is_dz		= self.gui.ch_dz_val.get()
			is_surface	= 1
			is_dx		= 0
			is_dy		= 0
			is_dz		= 1

			#is_surface	= 1
			#is_dx		= self.is_dx
			#is_dy		= self.is_dy
			#is_dz		= self.is_dz
			dep_idx	= -1

			params		= ( res_idx, dep_idx, dis_idx, type_idx, meas_dis_idx, sur_idx, is_dx, is_dy, is_dz, is_surface )
			#logging.debug("params: {}".format(params))
			#params		= (0, -1, 1, 2, 2, 0, 0, 0, 1, 1)
			# settings:
			# check-boxes
			#is_res_dz	= self.gui.ch_res_dz_val.get()
			#is_res_pr	= self.gui.ch_res_pr_val.get()
			#is_res_ym	= self.gui.ch_res_ym_val.get()
			#is_res_pp	= self.gui.ch_res_pp_val.get()
			is_res_dz	= 1
			is_res_pr	= 1
			is_res_ym	= 1
			is_res_pp	= 1

			settings	= ( is_res_dz, is_res_pr, is_res_ym, is_res_pp )

			logging.debug("settings: {}".format(settings))

			return (params, settings )

		except:
			helper.handle_exception()

	#--------------------------------------------
	def build_cmd( self, cmd_id ):
	#--------------------------------------------
		'''
		Builds a command.

		The command is made of:

			command id
			----------
			params:
			-------
				reservoir idx:				from reservoir list
				depletion idx:				from depletion list
				displacement idx:			from displacement list
				type idx:					from subsidence types list
											options: strain, pore pressure, compressibility
				meassured displacement idx: from displacement list
				is_dx:						from 'dx' check box
											if checked 'x' displacement is retrieved
				is_dy:						from 'dy' check box
											if checked 'y' displacement is retrieved
				is_dz:						from 'dz' check box
											if checked 'z' displacement is retrieved
				is_surface:					from 'surf' check box
											if checked 
												reservoir and displacements (measured and calculated) requests retrieves top surface values 
											otrherwise
												volume values are retrieved for reservoir and displacements (measured and calculated) requests
			settings:
			---------
				Poisons ratio request:		if true poisons ratio request is triggered
											not implemented
				Reduction factor request:	if true reduction factor request is triggered
											not implemented
			data:
			-----
				Pressure changement values calculated in the inversion process

		Command format depending on the command: 

			Cmd_Set_Depletion:				(cmd_id,params,settings,(points,vals))
			Rest of command:				(cmd_id,params,settings)
		'''
		try:
			params,settings=self.data()
			#if self.check_data( cmd_id, params, settings ):
			if params:

				if cmd_id == GeomecInterface.Request_Id.Cmd_Set_Depletion:
					from depletion import Depletion
					# (Depletion.Type) : Strain / Compressibility / PorePressure 
					#data	= Depletion.points_fake() 
					# KB: Take the calculated change in pressure and add this to the initial pressure. 
					# Note that this needs to be different for compressibility and strain???

					vals=[]
					if self.type_idx == Depletion.Type.Compressibility:
						# Invert for compressibility (Cm = e / deltaP).
						# Calculated Cm is deltaCm, so add original cm (self.avcm)
						# KB !IMPORTANT: still need to calculate deltaP instead of absolute initial P!!!!!!!
						vals = (self.gui.rec_par / self.gui.avpres) + self.gui.avcm
						# Update 'initial' compressiblity to an independent copy of updated compressibility for next step.
						self.gui.avcm = np.array(vals)
					elif self.type_idx == Depletion.Type.PorePressure:
						# Invert for pore pressure (deltaP = e / Cm).
						# Calculated deltaP needs to be added to previous absolute pressure.
						vals = (self.gui.rec_par / self.gui.avcm) + self.gui.prevpres
						# Update pore pressure for the next iteration step:
						self.gui.prevpres = np.array(vals)
					else: 
						# For strain, the first assumption is zero strain. For the consecutive iterations, add new strain to
						# previous strain results. 
						# KB: For now, use an ugly way (this will run the except the 1st time, after that it will add new strain)
						# to existing strain every time. 
						try:
							vals =  -self.gui.rec_par + self.gui.initial_strain
						except:
							vals = -self.gui.rec_par
						self.gui.initial_strain = np.array(vals)

					data = Depletion.points( vals )    
					# columns-> 0:x - 1:y - 2:z - 3:val
					points	= data[:,[Depletion.Pos.X,Depletion.Pos.Y,Depletion.Pos.Z]]

					vals	= data[:,Depletion.Pos.Val]
					cmd		= (cmd_id,params,settings,(points,vals))
					self.gui.textU.insert(1.0,'Depletion step set -- Next step: RUN GEOMEC\n','OK')
				else:
					cmd		= (cmd_id,params,settings)
				helper.log( cmd )
				return cmd

			else:
				ERROR_TEXT = """ERROR

				Command can't be sent with the selectd options."""
				self.popup( ERROR_TEXT )

		except:
			helper.handle_exception()

	#--------------------------------------------
	def is_implemented( self, cmd_id ):
	#--------------------------------------------
		cmd_implemented = (	GeomecInterface.Request_Id.Cmd_Get_Reservoir_List,
							GeomecInterface.Request_Id.Cmd_Get_Depletion_List,
							GeomecInterface.Request_Id.Cmd_Get_Displacement_List, 
							GeomecInterface.Request_Id.Cmd_Get_Reservoir, 
							GeomecInterface.Request_Id.Cmd_Get_Depletion, 
							GeomecInterface.Request_Id.Cmd_Get_Displacement,
							GeomecInterface.Request_Id.Cmd_Set_Depletion,
							GeomecInterface.Request_Id.Cmd_Remove_Depletion,
							GeomecInterface.Request_Id.Cmd_Run_Geomec,
							GeomecInterface.Request_Id.Cmd_Get_Material_Parameter,
							GeomecInterface.Request_Id.Cmd_Get_Measured_Displacement_List,
							GeomecInterface.Request_Id.Cmd_Get_Measured_Displacement,
							GeomecInterface.Request_Id.Cmd_Get_Surface_List )
							#GeomecInterface.Request_Id.Cmd_Quit )
		if cmd_id in cmd_implemented:
			return True
		else:
			return False

	#--------------------------------------------
	def _center(toplevel):
	#--------------------------------------------

		toplevel.update_idletasks()
		w = toplevel.winfo_screenwidth()
		h = toplevel.winfo_screenheight()
		size = tuple(int(_) for _ in toplevel.geometry().split('+')[0].split('x'))
		x = w/2 - size[0]/2
		y = h/2 - size[1]/2
		toplevel.geometry("%dx%d+%d+%d" % (size + (x, y)))

	#--------------------------------------------
	def popup( self, text_ ):
	#--------------------------------------------
		toplevel = tk.Toplevel() # FIXME: ???? 'self' instead of 'toplevel' ?
		label = tk.Label(toplevel, text=text_, height=0, width=100)
		#label = tk.Label(self.gui, text=text_, height=0, width=100)
		label.pack()
		#label.place(relx=0.5, rely=0.5, anchor=tk.CENTER) # doesn't work
		#_center( toplevel ) # doesn't work

	#--------------------------------------------
	def Pre_Cmd_Set_Depletion(self, _req):
	#--------------------------------------------
		# Helper function: activate the run Geomec button when setting depletion.
		self.send_req( _req )
		self.gui.b_rungm['state'] = 'active'      
		self.gui.b_setdep['state'] = 'disabled'   


	#--------------------------------------------
	def Pre_Cmd_Run_Geomec(self, _req):
	#--------------------------------------------
		# Helper function
		self.send_req( _req )
		self.gui.b_execute['state'] = 'disabled'
		self.gui.b_rungm['state'] = 'disabled'
		self.gui.textU.insert(1.0,'Running Geomec... After simulation, "Fill" Geomec Disp.\n','OK')

	#--------------------------------------------
	def send_req(self, req ):
	#--------------------------------------------
		'''
		Sends a request to GM.
		This is done in a separated thread to avoid freezing the GUI while waiting for the response.
		Response doesn't arrive in this methos but in 'process_queue()'.
		Before sending the request command is build using '_build_cmd()'
		Thread is implemented in 'ThreadedTask' class in 'threaded_task.py' module
		'''

		try:
			if self.is_processing_task:
				logging.debug('request cannot be processed because other request is being processed...')
			else:
				logging.debug('-->')
				logging.debug('send_req:{}'.format( req ) )
				#self.is_processing_task = True
				cmd_id=req
				logging.debug('cmd:{}'.format( GeomecInterface.Request_Id.name[ cmd_id ] ) )
				'''
				cmd_name=''
				if cmd_id < 100:
					cmd_name = GeomecInterface.Request_Id.name[ cmd_id ]
				else: #ENTENDED CMD
					cmd_name = GeomecInterfaceExt.Request_Id.name[ cmd_id - 100 ]
				logging.debug('cmd:{}'.format( cmd_name ) )	
				'''
				if self.is_implemented( cmd_id ):
					cmd = self.build_cmd( cmd_id )				
					if cmd:
						self.is_processing_task = True
						#logging.debug( 'inversion_GUI12_f:{}'.format( cmd ) )
						#self.textU.insert(1.0,'->   Req:  %s\n\n' % cmd_name ,'WARN')
						#self.gui.textU.insert(1.0,'->   Req:  %s\n\n' % GeomecInterface.Request_Id.name[ cmd_id ] ,'WARN')

						#self.progress()
						self.gui.prog_bar = ttk.Progressbar( self.gui, orient="horizontal",	length=200, mode="indeterminate" )
						self.gui.prog_bar.place(relx=0.5, rely=0.5, anchor=tk.CENTER)

						self.gui.prog_bar.start()
						self.queue = Queue.Queue()
						ThreadedTask( self.queue, cmd ).start()
						self.gui.after( self.POLLING_INTERVAL, self.process_queue )
					else:
						logging.debug('CMD NOT PROPERLY BUILD')
				else:
					self.textU.insert(1.0,'->   %s: NOT IMPLEMENTED YET\n\n' % GeomecInterface.Request_Id.name[ cmd_id ] ,'WARN')
					logging.debug('CMD NOT IMPLEMENTED YED')
		
		except:
			helper.handle_exception()

	#--------------------------------------------
	def gm_init(self,rij):
	#--------------------------------------------
		'''
		Method implemented just for testing.
		Creates some combo-boxes, buttons and check-boxes to test the integration GM-IT.
		Implemented in 'WidgetHelper' class in 'widget_helper.py' module 
		'''
		wh = WidgetHelper(self.gui, self) 
		return wh.create_widgets(row=rij)

	#--------------------------------------------
	def cb_newselection(self, event):
	#--------------------------------------------
		'''
		Triggers an event on any change in any of the test purpose combo boxes:
			Reservoir
			Depletion
			Displacement (calculated)
			Calculated pressure type: strain, pore pressure, compressibility
		'''
		
		caller = event.widget
		if caller == self.gui.cb_res:
			pass #logging.debug( 'Reservoir: text:{} pos:{}'.format( self.gui.cb_res.get(), self.gui.cb_res.current() ) )
		#elif caller == self.cb_dep:
		#	logging.debug( 'Depletion: text:{} pos:{}'.format( self.cb_dep.get(), self.cb_dep.current() ) )
		elif caller == self.gui.cb_dis:
			pass #logging.debug( 'Displacement: text:{} pos:{}'.format( self.gui.cb_dis.get(), self.gui.cb_dis.current() ) )
		elif caller == self.gui.cb_type:
			if self.gui.inverted:
				self.gui.plotresults()
			logging.debug( 'Type: text:{} pos:{}'.format( self.gui.cb_type.get(), self.gui.cb_type.current() ) )
		elif caller == self.gui.cb_show:
			if self.gui.resgrid:
				self.gui.setlimits()
				self.gui.plotreservoir()
			logging.debug( 'Property: text:{} pos:{}'.format( self.gui.show_type.get(), self.gui.show_type.current() ) )
		else:
			pass

	#--------------------------------------------
	def process_queue(self):
	#--------------------------------------------
		'''
		This emethod is called every 'POLLING_INTERVAL' time to check if the response to a request is available.
		Default time: 100ms.
		When respnse received it's treated in 'ResultsHandler' class in 'results_handler.py' module
		'''

		try:
			res = self.queue.get(0) # res: tuple( obj1, obj2, ..., objn )
									# obj1 = cmd = (cmd_id,param)

			try:
				self.is_processing_task = False
				logging.debug('process_queue : res : {}'.format(res))
				#cmd_id,params=res
				#cmd_id=res[0]
				#self.gui.textU.insert( 1.0,'  <-  res: %s\n' % GeomecInterface.Request_Id.name[ cmd_id ], 'WARN' )
				self.results_handler.handle( res )
				
				self.gui.prog_bar.stop()
				self.gui.prog_bar.destroy()

			except:
				helper.handle_exception()

		except Queue.Empty:
			self.gui.after( self.POLLING_INTERVAL, self.process_queue )

	#--------------------------------------------
	def key_release(self,e):
	#--------------------------------------------
		'''
		Method implemented just for testing.
		A comamnd is sent depending on the function key pushed.
		Implemented in 'KeyEventHandler' class in 'key_event_handler.py' module 
		'''
		try:
			from key_event_handler import KeyEventHandler as handler
			handler.handle( self.gui, e )
		except:
			helper.handle_exception()

