import logging
import helper #handle_exception
import numpy as np
import trimesh as trim # trimesh functions of Kees
# Just frir infi -> trim.trimesh.initiate(self.reservoirpoints,self.reservoirtriangles)

class Depletion:
	'''
	
	'''

	class Type:
		Strain=0
		Compressibility=1
		PorePressure=2

	class Pos:
		X=0
		Y=1
		Z=2
		Val=3

	@staticmethod
	def convert_to_cm( vals ):
		logging.debug("in convert_to_cm")
		return np.array( vals )

	@staticmethod
	def convert_to_pp( vals, init_vals, cm ):
		logging.debug("in convert_to_pp")
		return (np.array( vals ) / cm) + init_vals

	@staticmethod
	def points( vals ):
		try:
			#vals = np.array(vals)

			output = []
			# Here we take every triangle tri in trim.trimesh:
			for tri in range( trim.trimesh.nTri ):
				# The node id's belonging to this tri.s
				node1=trim.trimesh.pTris[tri,0]
				node2=trim.trimesh.pTris[tri,1]
				node3=trim.trimesh.pTris[tri,2]
				#this we can ignore for now
				#area=trim.trimesh.area[tri]
				#here we calculate the x and y coordinates of the center point of this triangle, based on the coords of the 3 nodes.
				x=(trim.trimesh.pnodes[node1-1,0]+trim.trimesh.pnodes[node2-1,0]+trim.trimesh.pnodes[node3-1,0])/3.
				y=(trim.trimesh.pnodes[node1-1,1]+trim.trimesh.pnodes[node2-1,1]+trim.trimesh.pnodes[node3-1,1])/3.
				# now get the specific strain (or pore pressure or compressibility) value for this triangle.
				val = vals[ tri ]
				# store x, y, value as N, E (i.e. reverse coords!)
				output.append( [ y, x, 0, val ] ) 
			logging.debug("output:{}", output)
			return np.array( output )
		except:
			helper.handle_exception()


	@staticmethod
	def points_fake():
		try:
			output=[] #[ x, y, z, val ]
			output.append( [ 1., 2., 3., 10. ] )
			output.append( [ 4., 5., 6., 20. ] )
			return np.array( output )
		except:
			helper.handle_exception()

